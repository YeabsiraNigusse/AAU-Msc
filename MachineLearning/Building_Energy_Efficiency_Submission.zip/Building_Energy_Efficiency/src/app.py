"""Serve the fitted building energy model over local HTTP."""

import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from time import perf_counter
from typing import Annotated

import joblib
import pandas as pd
from fastapi import FastAPI, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator

from src.features import FEATURES, TARGETS

ARTIFACT = Path(__file__).resolve().parents[1] / "artifacts" / "model.joblib"
logger = logging.getLogger("uvicorn.error")
Positive = Annotated[float, Field(gt=0, allow_inf_nan=False)]


class BuildingDesign(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    relative_compactness: Annotated[float, Field(gt=0, le=1)]
    surface_area: Positive
    wall_area: Positive
    roof_area: Positive
    overall_height: Positive
    glazing_area: Annotated[float, Field(ge=0, le=1)]
    orientation: Annotated[int, Field(ge=2, le=5)]
    glazing_area_distribution: Annotated[int, Field(ge=0, le=5)]

    @model_validator(mode="after")
    def check_design(self):
        if max(self.wall_area, self.roof_area) > self.surface_area:
            raise ValueError("Wall and roof areas must each be at most the surface area")
        if (self.glazing_area == 0) != (self.glazing_area_distribution == 0):
            raise ValueError("Use distribution code 0 exactly when glazing area is zero")
        return self


class LoadPrediction(BaseModel):
    heating_load: float
    cooling_load: float


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.bundle = joblib.load(ARTIFACT)
    yield


app = FastAPI(title="Building Energy Efficiency", lifespan=lifespan)


@app.middleware("http")
async def log_request(request: Request, call_next):
    start = perf_counter()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        record = {
            "path": request.url.path,
            "status": status,
            "latency_ms": round(1000 * (perf_counter() - start), 2),
            "outside_training_range": getattr(request.state, "outside_range", []),
        }
        logger.info("request_metrics %s", json.dumps(record))


@app.get("/health")
def health():
    return {"status": "ready"}


@app.post("/predict")
def predict(design: BuildingDesign, request: Request) -> LoadPrediction:
    values = design.model_dump()
    bundle = request.app.state.bundle
    request.state.outside_range = [
        field for field, (low, high) in bundle["training_bounds"].items()
        if not low <= values[field] <= high
    ]
    frame = pd.DataFrame([values], columns=FEATURES)
    prediction = bundle["pipeline"].predict(frame)[0]
    return LoadPrediction(**dict(zip(TARGETS, prediction.tolist())))
